# Informe de prueba

Este documento es completamente sintético. No contiene personas, identificadores ni expedientes reales.

## Datos de la entrega

- Código: DEMO-001
- Unidad: DEMO_A
- Estado: ejemplo de demostración

## Flujo documental

![Recepción, revisión y publicación](imagenes/flujo.png)

## Verificación

Sube nuevamente este mismo ZIP para comprobar la detección de duplicados.
